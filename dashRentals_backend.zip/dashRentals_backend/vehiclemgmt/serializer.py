from rest_framework.serializers import ModelSerializer
from .models import vehicleCheck

class vehicleTempDataSerializer(ModelSerializer):
    class Meta:
        model = vehicleCheck
        fields = '__all__'