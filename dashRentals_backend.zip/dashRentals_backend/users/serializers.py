from rest_framework.serializers import ModelSerializer
from .models import userDatabase

class userDataSerializer(ModelSerializer):
    class Meta:
        model = userDatabase
        fields = '__all__'