from django.db import models

# Create your models here.
class vehicleCheck(models.Model):
    location = models.TextField(blank=False)
    fromDate = models.DateField(blank=False)
    fromTime = models.TimeField(blank=False)
    
def __str__(self):
    return None
