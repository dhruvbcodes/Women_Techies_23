from django.db import models 

# Create your models here.
class userDatabase(models.Model):
    firstName = models.TextField(blank=False)
    lastName = models.TextField(blank=False)
    dateOfBirth = models.DateField()
    phoneNumber = models.IntegerField(unique=True)
    emailAddress = models.EmailField(blank=False, default='xyz@zyz.com')
    username = models.TextField(blank=False)
    creationDate = models.DateTimeField(auto_now_add=True)

def __str__(self):
    return None
