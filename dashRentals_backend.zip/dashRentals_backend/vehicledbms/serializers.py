from rest_framework.serializers import ModelSerializer
from .models import vehicleDatabase

class vehicleDataSerializer(ModelSerializer):
    class Meta:
        model = vehicleDatabase
        fields = '__all__'