from django.shortcuts import render
from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import vehicleDatabase
from .serializers import vehicleDataSerializer

# Create your views here


@api_view(["GET","POST","DELETE"])
# Create your views here.
def vehicleDataFetch(requests):
    routes = [{
        'Endpoints':'/vehicleData/vehicleNo/',
        'method':'POST',
        'vehicleNo': {'vehicleNo':""},
        'description':'Adds location to the database recieved from post method'        
    },
    {
        'Endpoints':'/vehicleData/vehicleModel/',
        'method':'POST',
        'vehicleModel': {'vehicleModel':""},
        'description':'Adds "from date" to the database recieved from post method'    
    },
    {
        'Endpoints':'/vehicleData/vehicleMakeTear/',
        'method':'POST',
        'vehicleModel': {'vehicleModel':""},
        'description':'Adds "from date" to the database recieved from post method'    
    },
    {
        'Endpoints':'/vehicleData/kmsDriven/',
        'method':'POST',
        'vehicleModel': {'vehicleModel':""},
        'description':'Adds "from date" to the database recieved from post method'    
    },
    
    ]
    return Response(routes)


@api_view(['GET'])
def getUserdata(requests):
    userData = vehicleDatabase.objects.all()
    serializer = vehicleDataSerializer(userData, many=True)
    return Response(serializer.data)
