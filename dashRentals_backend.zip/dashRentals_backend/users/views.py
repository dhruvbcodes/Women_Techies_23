from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from django.http import HttpResponse
from django.contrib.auth.forms import UserCreationForm

from .models import *
# from .forms import orderForm
# from .filters import orderFilter

def registerPage(request):
    context = {}
    return render(request, 'register.html')

def loginPage(requests):
    context = {}
    return render(requests, 'login.html')



from .models import userDatabase
from .serializers import userDataSerializer


# @api_view(["GET","POST","DELETE"])
# # Create your views here.
# def getRoutes(requests):
#     routes = [{
#         'Endpoints':'/intro/location/',
#         'method':'POST',
#         'location': {'location':""},
#         'description':'Adds location to the database recieved from post method'        
#     },
#     {
#         'Endpoints':'/intro/fromdate/',
#         'method':'POST',
#         'fromdate': {'fromdate':""},
#         'description':'Adds "from date" to the database recieved from post method'    
#     }]
#     return Response(routes)


@api_view(['GET'])
def getUserdata(requests):
    userData = userDatabase.objects.all()
    serializer = userDataSerializer(userData, many=True)
    return Response(serializer.data)

